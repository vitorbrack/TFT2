
//De acordo com a suite escolhida o hospede já tem marcados as refeições



//Nome Completo



//E-mail


//Tratando do CPF



//Data de Nascimento - Uma outra forma de declarar eventos, utilizando Arrow Functions



//Telefone



//Senha



//Mostra Senha


//Termos de Privacidade


//Botão de Envio sem termo exibe caixa de alerta
